---
name: weekly-plan
description: Generate a weekly Platform Finance marketing content plan. Invoke when asked to plan content, create a content calendar, or schedule marketing for the week or month.
argument-hint: [week number or date range] [optional: upcoming campaigns or events]
---

# Weekly Marketing Plan Skill

Generate a **structured weekly content plan** for Platform Finance marketing.

## How to Use This Skill

If the user provided an argument (`$1`), use it as the **week or time period**.  
If no argument was provided, use the current week and ask: *"Any specific campaigns, events, or themes coming up I should factor in? (e.g. EOFY, a product push, aggregator PD day, rate decision)"*

## What to Produce

A full content plan for the week covering:

### LinkedIn (2 posts)
For each post, provide:
- **Day:** Recommended publish day (Tue or Thu recommended for B2B)
- **Theme:** The single idea for the post
- **Hook concept:** The first-line angle (don't write the full post — just the hook direction)
- **Why now:** Why this angle is relevant this week

### EDM (if due this month)
- **Send day:** Recommended send day (Tue/Wed recommended)
- **Theme:** Campaign focus
- **Angle:** The key hook or data point to lead with
- **CTA:** Recommended call to action

### Optional: Try-Call / SMS Blast
If relevant to the week's theme, suggest:
- **Target segment:** Which brokers to call/text
- **Message angle:** 1-sentence SMS or call hook

## Output Format

---

## Platform Finance — Content Plan: [Week of DATE]

**Theme of the week:** [Overarching narrative thread across content]

---

### LinkedIn Post 1 — [Day]
- **Theme:** 
- **Hook direction:** 
- **Why this week:** 

### LinkedIn Post 2 — [Day]
- **Theme:** 
- **Hook direction:** 
- **Why this week:** 

---

### EDM — [Day] *(if due)*
- **Campaign theme:** 
- **Lead angle:** 
- **CTA:** 

---

### Try-Call / SMS *(optional)*
- **Target:** 
- **Angle:** 

---

**Notes:** [Any seasonal context, upcoming events, or strategic reminders]

---

## After Generating

Save the plan to `content/plan-[year]-W[week number].md` and confirm the file was saved.

Then ask: *"Want me to start drafting any of these now? Just say '/linkedin-posts [theme]' or '/edm [theme]' to kick one off."*
