---
name: edm
description: Generate a full Platform Finance EDM (email campaign) for mortgage brokers. Invoke when asked to write, create, or draft an EDM, broker email, email campaign, or newsletter.
argument-hint: [theme or campaign focus] [optional: seasonal context]
---

# EDM (Email Campaign) Skill

Generate a **complete, ready-to-send EDM** for Platform Finance, targeting mortgage brokers.

## How to Use This Skill

If the user provided an argument (`$1`), use it as the **campaign theme or focus**.  
If no argument was provided, ask: *"What's the focus for this EDM? (e.g. EOFY, personal loans, commercial assets, rate environment, Tick & Flick intro, debt consolidation, refinance opportunities)"*

Also consider: What month/season is it? Incorporate any timely context (EOFY = June, rate decisions, new year, tax time, etc.)

## EDM Structure (Always Follow This)

### 1. Subject Line
- Max 8 words
- Curiosity-driven — broker wants to open it
- Avoid generic phrases like "Don't miss out" or "Important update"
- Examples of strong subjects:
  - *"Your clients are buying cars without you"*
  - *"EOFY: The deals hiding in your database"*
  - *"One referral. One hour. Extra income."*

### 2. Preview Text
- 1 sentence (appears after subject line in inbox)
- Tease the content — don't repeat the subject
- Max 90 characters

### 3. Opening Paragraph
- 2–3 sentences max
- Hook immediately — a stat, a scenario, or a direct broker challenge
- Sets up why this email matters *right now*

### 4. Body
- Insight or market opportunity relevant to the theme
- Connect it to broker revenue, client retention, or simplicity
- Reference Platform Finance stats where natural:
  - 60+ lenders, 9,000+ brokers, largest processing centre
- Mention relevant pathway (Tick & Flick / Hands on the Wheel / Direct to Lender) if it fits
- Use Equifax/ABS/MFAA data if relevant

### 5. Broker Takeaways
- 3–4 bullet points
- Each = a practical, actionable insight or benefit
- Keep them punchy (1 line each)

### 6. Call to Action
Choose the most appropriate CTA:
- "Refer your first deal today → broker.platform.com.au"
- "Speak to your BDM — [contact context]"
- "Get accredited in minutes → broker.platform.com.au"
- "Log in and submit a deal → broker.platform.com.au"

### 7. Sign-Off
Always close as:
```
Warm regards,

Jaymie Toma
Senior Business Development Manager | Platform Finance
broker.platform.com.au
```

## Tone Reminders

- Broker-first — every paragraph answers "why does this matter to me?"
- Confident and credible — backed by data or real scenarios
- Slightly cheeky where it lands — never unprofessional
- Short sentences. White space. Scannable.

## Output Format

Deliver the complete EDM in this structure:

---

**SUBJECT LINE:** [subject line here]

**PREVIEW TEXT:** [preview text here]

---

[Full email body, properly formatted with paragraph breaks]

---

## After Generating

Save the output to `content/edm-[today's date].md` and confirm the file was saved.

Then ask: *"Want to adjust the tone, swap the CTA, or generate a second version with a different angle?"*
