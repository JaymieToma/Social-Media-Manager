---
name: linkedin-posts
description: Generate 2 Platform Finance LinkedIn posts for mortgage brokers. Invoke when asked to write, create, or generate LinkedIn content, social posts, or broker social media.
argument-hint: [theme] [optional: extra context]
---

# LinkedIn Posts Skill

Generate **2 LinkedIn post options** for Platform Finance, targeting mortgage brokers.

## How to Use This Skill

If the user provided an argument (`$1`), use it as the content **theme or focus**.  
If no argument was provided, ask: *"What theme or angle for this week's LinkedIn posts? (e.g. diversification, EOFY, Tick & Flick, missing deals, speed, personal loans, commercial assets)"*

## Post Requirements (Apply to Both Options)

- **Length:** 80–150 words per post
- **Hook:** First line must stop the scroll — a bold stat, punchy question, or provocative claim
- **One idea only:** Each post covers a single angle — no kitchen-sink posts
- **Broker-first:** Every line answers "what's in it for the broker?"
- **Tone:** Confident, clear, slightly cheeky — never corporate
- **Hashtags:** 3 maximum, relevant, no spam
- **CTA:** Soft — invite them to DM, comment, or visit broker.platform.com.au
- **No fluff:** If a sentence doesn't add value, cut it

## Content Themes to Draw From

- Deals brokers are missing right now
- Asset finance as a client retention tool
- How simple Tick & Flick actually is
- EOFY / seasonal opportunities
- Speed of Platform approvals vs banks
- Market data (Equifax, ABS, MFAA)
- Personal loan opportunities alongside mortgages
- Commercial asset finance for SME clients
- Broker income diversification
- Real-world use cases / broker scenarios

## Output Format

Write both options clearly, ready to copy-paste into LinkedIn:

---

**OPTION 1**

[Full post text, formatted with line breaks as LinkedIn would show it]

---

**OPTION 2**

[Full post text, formatted with line breaks as LinkedIn would show it]

---

## After Generating

Save the output to `content/linkedin-[today's date].md` and confirm the file was saved.

Then ask: *"Want me to tweak either option, generate two more, or move on to the EDM?"*
