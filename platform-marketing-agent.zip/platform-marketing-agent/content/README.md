# Content Output

Generated marketing content is saved here automatically.

Files created by Claude Code:
- `linkedin-YYYY-MM-DD.md` — LinkedIn post options
- `edm-YYYY-MM-DD.md` — EDM / email campaigns
- `plan-YYYY-WNN.md` — Weekly content plans
