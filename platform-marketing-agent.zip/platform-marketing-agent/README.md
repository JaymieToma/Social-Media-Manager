# Platform Finance Marketing Agent — Claude Code

A Claude Code project that acts as your personal marketing agent. Open this folder in Claude Code and it's instantly briefed on Platform Finance, your audience, and your brand voice — ready to generate LinkedIn posts, EDMs, and weekly content plans on demand.

---

## Setup

### 1. Install Claude Code

```bash
npm install -g @anthropic-ai/claude-code
```

Requires a Claude Pro, Max, or API subscription. See [claude.ai](https://claude.ai) to get started.

### 2. Open This Project

```bash
cd platform-marketing-agent
claude
```

Claude Code automatically loads `CLAUDE.md` — your full Platform Finance brief is loaded into every session. No re-briefing needed.

---

## Commands

### `/linkedin-posts [theme]`

Generates 2 LinkedIn post options targeting mortgage brokers.

```
/linkedin-posts EOFY deals
/linkedin-posts Tick & Flick simplicity
/linkedin-posts personal loans alongside mortgages
/linkedin-posts deals brokers are missing
```

No theme provided? Claude will ask you for one.

---

### `/edm [theme]`

Generates a full, ready-to-send EDM campaign email.

```
/edm EOFY asset finance opportunities
/edm debt consolidation personal loans
/edm new broker intro — Tick & Flick
/edm commercial assets for SME clients
```

Includes subject line, preview text, full body, broker takeaways, CTA, and sign-off.

---

### `/weekly-plan [week]`

Generates a structured content calendar for the week.

```
/weekly-plan this week
/weekly-plan week of April 14
/weekly-plan — EOFY push starting
```

Covers both LinkedIn posts and EDM scheduling, plus optional try-call/SMS angles.

---

## Natural Language Works Too

Claude Code loads the skills contextually, so you can also just talk to it:

```
Write me two LinkedIn posts about how brokers are missing car loan deals
Draft an EDM for EOFY with a focus on commercial trucks and equipment
Plan out my content for the next two weeks — EOFY is coming up
Give me a punchy subject line for a broker email about personal loans
```

---

## Output Files

All generated content is saved automatically to the `content/` folder:

| File | Content |
|---|---|
| `content/linkedin-YYYY-MM-DD.md` | LinkedIn post options |
| `content/edm-YYYY-MM-DD.md` | Full EDM copy |
| `content/plan-YYYY-WNN.md` | Weekly content plan |

---

## Project Structure

```
platform-marketing-agent/
├── CLAUDE.md                         ← Platform Finance brief (auto-loaded)
├── README.md                         ← This file
├── content/                          ← Generated content saved here
└── .claude/
    └── skills/
        ├── linkedin-posts/
        │   └── SKILL.md              ← /linkedin-posts command
        ├── edm/
        │   └── SKILL.md              ← /edm command
        └── weekly-plan/
            └── SKILL.md              ← /weekly-plan command
```

---

## Tips

- **Be specific with themes** — the more context you give, the sharper the output
- **Regenerate freely** — just ask "give me two more" or "try a different angle"
- **Seasonal context** — mention upcoming events (EOFY, rate decisions, aggregator PD days) for timely content
- **Combine commands** — run `/weekly-plan` first to map the week, then use `/linkedin-posts` and `/edm` to execute
- **Edit in place** — ask Claude to "make Option 1 punchier" or "swap the CTA to Tick & Flick"

---

## Support

For Platform Finance broker tools and accreditation: [broker.platform.com.au](https://broker.platform.com.au)
